const User = require('../models/user');

class UserController {
  // Implemente os métodos do controlador para manipular usuários
}

module.exports = UserController;
